

//var c = 300
//let a = 300

//if (true) {
 //    let a = 10
 //    const b = 20
     //console.log("INNER: ", a);
//}

//console.log(a);
//console.log(b);
//console.log(c);

//scope level and mini hoisting************************************************************

//function one(){
//	const username = "hitesh"

//	function two(){
//		const website = "youtube"
		//console.log(username);
//	}
	//console.log(website);

//	two()
//}

//one()

//if (true) {
//	const username = "hitesh"
//	if (username === "hitesh") {
//		const website = "youtube"
		//console.log(username + website);
//	}
	//console.log(website);

//}
//console.log(username);






//***********************************interesting**************************************




//console.log(addone(5))


//function addone(num){
//	return num + 1
//}


//addtwo(5)


//const addtwo = function(num){
//	return num + 2
//}




//***********************this and arrow function********************************




//const user = {
//	username: "hitesh",
//	price: 999,

//	welcomeMessage: function() {
//		console.log(`${this.username} , welcome to website`);
//		console.log(this);
//	}
//}

//user.welcomeMessage()
//user.username = "sam"
//user.welcomeMessage()

//console.log(this);


//function chai(){
//	let username = "hitesh"
//	console.log(this.username);
//}

//chai()

//const chai = function () {
//	let username = "hitesh"
//	console.log(this.username);
//}


//const chai =  () => {
//	let username = "hitesh"
//	console.log(this);
//}

//chai()


//const addTwo = (num1, num2) => {
//	return num1 + num2
//}



//const addTwo = (num1, num2) =>  num1 + num2
//const addTwo = (num1, num2) =>  (num1 + num2)
//const addTwo = (num1, num2) =>  ({username: "hitesh"})


//console.log(addTwo(3, 4))








//**************************Immediately invoked function*************************************


//****************Immediately invoked function expressions*********(IIFE)*************



(function chai(){
	//name IIFE
	//console.log(`DB CONNECTED`);
})();



( () => {
    //console.log(`DB CONNECTED TWO`);
})();


( (name) => {
   // console.log(`DB CONNECTED TWO ${name}`);
})('hitesh')







//**************how does javascript works behind the scene****************************************




let val1 = 10
let val2 = 5
function addNum(num1, num2 ){
	let total = num1 + num2
	return total
}
let result1 = addNum(val1, val2)
let result2 = addNum(10, 2)